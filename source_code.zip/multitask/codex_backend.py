"""Independent no-tool Codex CLI turns. Never uses the school transport."""
import json,pathlib,subprocess,time,hashlib,shutil,os,signal,threading,tempfile
HERE=pathlib.Path(__file__).resolve().parent
DISABLED=['shell_tool','shell_snapshot','apps','plugins','remote_plugin','browser_use','browser_use_external','computer_use','in_app_browser','image_generation','view_image','multi_agent','multi_agent_v2','code_mode','code_mode_host','workspace_dependencies','skill_search','memories','hooks','sleep_tool','unbounded_connection_retries']
WARNINGS=['Under-development features enabled: skip_host_skill_discovery','Code Mode is unavailable because code-mode host is disabled']
class Shared:
 def __init__(self):self.lock=threading.Lock();self.calls=0;self.input=0;self.output=0;self.cached=0;self.unknown=0;self.bad_streak=0;self.abort=False;self.records=[]
 def begin(self):
  with self.lock:self.calls+=1;return self.calls
 def finish(self,record):
  with self.lock:
   self.records.append(record);self.input+=record['input_tokens'];self.output+=record['output_tokens'];self.cached+=record['cached_input_tokens'];self.unknown+=not record['usage_complete']
 def snapshot(self):
  with self.lock:return {'cli_invocations':self.calls,'input_tokens':self.input,'output_tokens':self.output,'cached_input_tokens':self.cached,'unknown_usage_invocations':self.unknown,'abort':self.abort,'calls':self.records[:]}
def parse_native(stdout,final):
 events=[]
 for line in stdout.splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
 usage=[e['usage'] for e in events if e.get('type')=='turn.completed' and isinstance(e.get('usage'),dict)]
 complete=len(usage)==1 and all(type(usage[0].get(k)) is int and usage[0][k]>=0 for k in ['input_tokens','output_tokens'])
 unexpected=[]
 for e in events:
  item=e.get('item',{});kind=item.get('type')
  if kind in [None,'agent_message','reasoning']:continue
  if kind=='error' and any(x in item.get('message','') for x in WARNINGS):continue
  unexpected.append(e)
 output=None
 try:output=json.loads(final)
 except ValueError:pass
 return events,usage,complete,unexpected,output
class CodexBackend:
 def __init__(self,out,shared,timeout_s=600):
  self.timeout_s=timeout_s;self.bad_streak=0;self.abort=False;self.out=pathlib.Path(out);self.shared=shared;self.calls=0;self.known_tokens=0;self.usage_complete=True;self.schemas=json.loads((HERE/'schemas.json').read_text());self.cwd=pathlib.Path(tempfile.mkdtemp(prefix='cx-session-',dir='/private/tmp'))
 def log(self,e):
  with (self.out/'calls.jsonl').open('a') as f:f.write(json.dumps(e)+'\n');f.flush();os.fsync(f.fileno())
 def ask(self,run,role,messages):
  if self.calls>=16:raise ValueError('Common per-workflow 16-invocation ceiling')
  if not self.usage_complete:raise ValueError('Previous CLI usage unknown; no automatic retry within workflow')
  if self.abort:raise ValueError('This workflow local guard stopped launches')
  self.calls+=1;global_id=self.shared.begin();ident='call-'+str(global_id);directory=self.out/'cli'/ident;directory.mkdir(parents=True,exist_ok=False)
  instruction=(HERE/(role+'.txt')).read_text() if (HERE/(role+'.txt')).exists() else messages[0]['content'];prompt=messages[1]['content'];schema=self.schemas[role]
  (directory/'system.txt').write_text(instruction);(directory/'prompt.json').write_text(prompt);(directory/'schema.json').write_text(json.dumps(schema,indent=2));actual_messages=[{'role':'system','content':instruction},{'role':'user','content':prompt}]
  args=[shutil.which('codex'),'--no-daemon','-a','never','exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--color','never','--json','--model','gpt-6.1-sol','-C',str(self.cwd),'--output-schema',str(directory/'schema.json'),'-o',str(directory/'final.json')]
  for flag in DISABLED:args+=['--disable',flag]
  args+=['--enable','skip_host_skill_discovery']
  for value in ['web_search="disabled"','project_doc_max_bytes=0','model_reasoning_effort="low"','model_instructions_file='+json.dumps(str(directory/'system.txt'))]:args+=['-c',value]
  args+=['-'];(directory/'command.json').write_text(json.dumps(args,indent=2))
  self.log({'event':'call_started','call_id':ident,'run_id':run,'role':role,'start_epoch':time.time(),'request':{'model':'gpt-6.1-sol','reasoning_effort':'low','messages':actual_messages,'output_schema':schema},'native_trace':str(directory.relative_to(self.out))})
  env=os.environ.copy()
  for key in ['OPENAI_API_KEY','OPENAI_BASE_URL','CODEX_API_KEY']:env.pop(key,None)
  started=time.monotonic();timeout=False;launch_error=None;code=None
  try:
   with (directory/'events.jsonl').open('w') as stdout,(directory/'stderr.txt').open('w') as stderr:
    proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,text=True,env=env,start_new_session=True)
    try:proc.communicate(prompt,timeout=self.timeout_s)
    except subprocess.TimeoutExpired:
     timeout=True;os.killpg(proc.pid,signal.SIGTERM);proc.communicate()
    except KeyboardInterrupt:
     os.killpg(proc.pid,signal.SIGTERM);proc.communicate();raise
    code=proc.returncode
  except Exception as exc:launch_error=type(exc).__name__
  stdout=(directory/'events.jsonl').read_text() if (directory/'events.jsonl').exists() else '';final=(directory/'final.json').read_text() if (directory/'final.json').exists() else ''
  events,usage,complete,unexpected,obj=parse_native(stdout,final);self.usage_complete=complete
  it=sum(u.get('input_tokens',0) for u in usage);ot=sum(u.get('output_tokens',0) for u in usage);cached=sum(u.get('cached_input_tokens',0) for u in usage);self.known_tokens+=it+ot
  isolation=any(e.get('item',{}).get('type') not in ['error',None] for e in unexpected)
  success=code==0 and not timeout and not launch_error and complete and len(usage)==1 and not unexpected and isinstance(obj,dict)
  record={'call_id':ident,'run_id':run,'role':role,'success':success,'usage_complete':complete,'input_tokens':it,'output_tokens':ot,'cached_input_tokens':cached,'native_usage_events':usage,'exit_code':code,'timeout':timeout,'launch_error':launch_error,'unexpected_items':unexpected,'isolation_violation':isolation,'latency_s':time.monotonic()-started};self.bad_streak=0 if success else self.bad_streak+1;self.abort=isolation or self.bad_streak>=3;self.shared.finish(record)
  # Compatibility envelope is explicitly adapter-normalized; native events remain authoritative.
  envelope={'choices':[{'message':{'content':final},'finish_reason':'stop' if success else None}],'usage':{'prompt_tokens':it,'completion_tokens':ot,'total_tokens':it+ot}}
  self.log({'event':'call_completed' if complete else 'call_failed',**record,'usage':envelope['usage'] if complete else None,'raw_response':envelope,'raw_response_format':'adapter_normalized_from_native_CLI','native_events_types':[e.get('type') for e in events]})
  (directory/'result.json').write_text(json.dumps(record,indent=2))
  if not success:raise ValueError('Codex CLI failed; see native trace (exit='+str(code)+', usage_complete='+str(complete)+', timeout='+str(timeout)+')')
  return obj
