from run import *
from collections import defaultdict
from decimal import Decimal
c=connect();types=defaultdict(set)
for account,kind in c.execute('SELECT account_name,account_type FROM chart_of_accounts WHERE businessID=25'):types[account].add(kind)
totals=defaultdict(Decimal);ids=set()
for tid,date,kind,account,customer,credit,due,balance in c.execute('SELECT transaction_id,transaction_date,transaction_type,account,customers,credit,due_date,open_balance FROM master_txn_table WHERE businessID=25'):
 if '2022-04-01'<=date<='2023-03-31' and kind in ['invoice','deposit'] and customer not in [None,'','--','nan'] and len(types[account])==1 and next(iter(types[account])) in ['income','other income']:totals[customer]+=Decimal(str(credit or 0))
 if kind=='invoice' and date<='2023-04-01' and balance is not None and balance>0 and due is not None and '2023-04-02'<=due<='2023-05-01':ids.add(tid)
expected4=[{'entity':k,'value':float(v.quantize(Decimal('.01')))} for k,v in sorted(totals.items(),key=lambda x:(-x[1],x[0]))[:3]];expected6=[{'entity':str(k),'value':1} for k in sorted(ids)]
assert expected4==execute('B04',query(c,SQL4),canonical('B04'));assert expected6==execute('B06',query(c,SQL6),canonical('B06'))
(HERE/'independent_raw_audit.json').write_text(json.dumps({'method':'Python Decimal grouping and set filtering of raw transaction rows, independent of SQL JOIN/aggregation','B04':expected4,'B06':expected6,'passed':True},indent=2));print('Independent raw-row checks passed for both tasks.');c.close()
