from pathlib import Path
import json,re,sqlite3,collections
import sys;B=Path(__file__).resolve().parents[1];P=Path(sys.argv[1]).resolve();schedule=json.loads((P/'schedule.json').read_text());c=sqlite3.connect('file:'+str(B/'data/accounting.sqlite')+'?mode=ro',uri=True)
values={str(x[0]) for x in c.execute('SELECT DISTINCT transaction_type FROM master_txn_table WHERE businessID=25')}|{str(x[0]) for x in c.execute('SELECT DISTINCT account_type FROM chart_of_accounts WHERE businessID=25')};canon={s.casefold():s for s in values};allcalls=[];flags=[]
for folder in sorted(P.glob('job*')):
 n=int(folder.name[3:]);task,fault,policy,rep=schedule[n];callfile=folder/'calls.jsonl'
 if not callfile.exists():continue
 idx=0
 for l in callfile.read_text().splitlines():
  e=json.loads(l)
  if e['event'] not in ['call_completed','call_failed'] or e['role']!='generation_A':continue
  idx+=1;record={'job':n+1,'task':task,'fault':fault,'policy':policy,'A_ordinal':idx,'completed':e['success']};allcalls.append(record)
  if not e['success']:continue
  sql=json.loads(e['raw_response']['choices'][0]['message']['content'])['sql'];literals=re.findall(r"'([^']*)'",sql);mismatch=[v for v in literals if v.casefold() in canon and v!=canon[v.casefold()]]
  if mismatch:
   corrected=sql
   for v in mismatch:corrected=corrected.replace("'"+v+"'","'"+canon[v.casefold()]+"'")
   try:
    a=c.execute(sql).fetchall();b=c.execute(corrected).fetchall();changes=a!=b
   except Exception as exc:changes=None;a=[];b=[]
   flags.append({**record,'mismatched_literals':mismatch,'original_rows':len(a),'case_corrected_rows':len(b),'changes_result':changes,'sql':sql})
c.close();groups=[]
for task in ['B04','B06']:
 for scope in ['clean','nonclean','all']:
  rs=[r for r in allcalls if r['task']==task and (scope=='all' or (r['fault']=='clean')==(scope=='clean'))];bad=[r for r in flags if r['task']==task and r['changes_result'] and (scope=='all' or (r['fault']=='clean')==(scope=='clean'))]
  groups.append({'task':task,'scope':scope,'completed_A_calls':sum(r['completed'] for r in rs),'case_sensitive_value_errors':len(bad)})
result={'partial':len(list(P.glob('job*/outcome.json')))<150,'calls_observed':len(allcalls),'groups':groups,'flags':flags};(P/'A_case_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
