import copy,json
from run import *
c=connect();audit={}
for t in ['B04','B06']:
 source=query(c,SQL4 if t=='B04' else SQL6);out=execute(t,source,canonical(t));ref=query(c,TASKS[t]['reference_sql']);expected=[{'entity':str(r[0]),'value':round(r[1],2) if t=='B04' else 1} for r in ref];assert out==expected
 wrong=copy.deepcopy(source)
 if t=='B04':next(r for r in wrong if r[0]=='brett melendez' and r[1]=='current')[2]+=1000;p=canonical(t);p['adjustments']=[{'entity':'brett melendez','delta':1000}]
 else:next(r for r in wrong if r[0]==144854)[2]='2023-05-02';p=canonical(t);p['exclude_ids']=[144854]
 assert execute(t,wrong,canonical(t))!=expected;assert execute(t,source,p)!=expected
 audit[t]={'candidate_rows':len(source),'truth':expected,'incorrect_affects_result':True,'instruction_requested_plan_affects_result':True}
c.close();(HERE/'offline_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
