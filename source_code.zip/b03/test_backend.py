import unittest,tempfile,pathlib,json
from unittest.mock import patch
from codex_backend import parse_native,CodexBackend,Shared
class Tests(unittest.TestCase):
 def test_native_warning_not_tool(self):
  events=[{'type':'item.completed','item':{'type':'error','message':'Code Mode is unavailable because code-mode host is disabled. closed'}},{'type':'turn.completed','usage':{'input_tokens':12,'output_tokens':4,'cached_input_tokens':3}}]
  _,u,ok,unexpected,obj=parse_native('\n'.join(map(json.dumps,events)),'{"accept":true}')
  self.assertTrue(ok);self.assertFalse(unexpected);self.assertEqual(obj,{'accept':True})
 def run_fake(self,tool=False):
  class Fake:
   def __init__(self,args,**kw):self.args=args;self.stdout=kw['stdout'];self.returncode=0
   def communicate(self,prompt,timeout=None):
    pathlib.Path(self.args[self.args.index('-o')+1]).write_text('{"accept":true,"reason":"test"}')
    if tool:self.stdout.write(json.dumps({'type':'item.completed','item':{'type':'command_execution','command':'forbidden'}})+'\n')
    self.stdout.write(json.dumps({'type':'turn.completed','usage':{'input_tokens':10,'output_tokens':5}})+'\n');self.stdout.flush()
  with tempfile.TemporaryDirectory() as d:
   shared=Shared();b=CodexBackend(d,shared)
   with patch('codex_backend.subprocess.Popen',Fake):
    if tool:
     with self.assertRaises(ValueError):b.ask('opaque','verification_A',[{'content':'system'},{'content':'{}'}])
    else:self.assertTrue(b.ask('opaque','verification_A',[{'content':'system'},{'content':'{}'}])['accept'])
   self.assertEqual(b.known_tokens,15);self.assertEqual(b.abort,tool);self.assertFalse(shared.abort)
 def test_accounting(self):self.run_fake()
 def test_isolation_violation_stops(self):self.run_fake(True)
if __name__=='__main__':unittest.main()
