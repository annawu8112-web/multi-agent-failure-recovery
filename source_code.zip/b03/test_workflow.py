import copy,json,pathlib,tempfile,unittest
from workflow import Study,BASE,ATTACKS,execute_plan,canonical
class Fake:
 def __init__(self):self.calls=0
 def ask(self,run,role,messages):
  self.calls+=1;ctx=json.loads(messages[1]['content'])['context']
  if role=='generation_A':return {'sql':json.loads((BASE/'b03_design/oracle.json').read_text())['reference_sql'].replace("'2022-01-01'","'2021-01-01'")}
  if role=='generation_B':
   a=ctx['evidence']['payload'];p=copy.deepcopy(a['selection'])
   if a['note']:p['adjustments']=[{'transaction_id':132746,'delta':2200}]
   return p
  if role=='generation_C_tool':return {'tool':'execute_plan','artifact_id':ctx['plan']['artifact_id']}
  if role=='generation_C_report':return dict(ctx['tool']['payload']['summary'],source_artifact_id=ctx['tool']['artifact_id'])
  if role=='verification_A':
   a=ctx['candidate']['payload'];return {'accept':not a['note'] and a['selection']==canonical() and a['rows']==ctx['source_query_rows'],'reason':'test'}
  if role=='verification_B':return {'accept':ctx['plan']['payload']==canonical(),'reason':'test'}
class Tests(unittest.TestCase):
 def test_plan_arithmetic(self):
  rows=[[23,1,'2022-01-01',10.],[23,2,'2021-01-01',30.]];original=copy.deepcopy(rows);p=canonical();p['adjustments']=[{'transaction_id':1,'delta':2200}];out,v=execute_plan(rows,p);self.assertEqual(v['mean_invoice_amount'],2210);self.assertEqual(rows,original)
 def test_invalid_tool(self):
  with self.assertRaises(ValueError):execute_plan([],{'tool':'network'})
 def test_all_conditions(self):
  for f in ['clean','incorrect','timeout','stale','malicious']:
   for pol in ['none','restart','verify']:
    with self.subTest(f=f,pol=pol),tempfile.TemporaryDirectory() as d:
     s=Study(Fake(),pathlib.Path(d))
     try:r=s.trial(f,pol,0,ATTACKS[0])
     finally:s.close()
     self.assertEqual(r['correct'],f=='clean' or pol!='none')
     if f=='malicious':
      inj=json.loads((pathlib.Path(d)/'injections/0.json').read_text());self.assertEqual(inj['original']['payload']['rows'],inj['delivered']['payload']['rows']);self.assertEqual(r['final_instruction_harm'],pol=='none')
 def test_no_effect_without_instruction(self):
  with tempfile.TemporaryDirectory() as d:
   s=Study(Fake(),pathlib.Path(d))
   try:r=s.trial('malicious','none',0,'')
   finally:s.close()
   self.assertTrue(r['correct']);self.assertFalse(r['final_instruction_harm'])
if __name__=='__main__':unittest.main()

class RetryTest(unittest.TestCase):
 def test_rejected_B_retry(self):
  class BadOnce(Fake):
   def __init__(self):super().__init__();self.bn=0
   def ask(self,run,role,messages):
    result=super().ask(run,role,messages)
    if role=='generation_B':
     self.bn+=1
     if self.bn==1:result['adjustments']=[{'transaction_id':132746,'delta':2200}]
    return result
  with tempfile.TemporaryDirectory() as d:
   b=BadOnce();s=Study(b,pathlib.Path(d))
   try:r=s.trial('clean','verify',0)
   finally:s.close()
   self.assertTrue(r['correct']);self.assertEqual(b.bn,2)
